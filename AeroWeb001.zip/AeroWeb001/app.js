var database = firebase.database();
var shiftList = database.ref('shiftList');


// const lampangOnDuty = database.ref('lampang');
// const chiangraiOnDuty = database.ref('chiangrai');
// const maehongsonOnDuty = database.ref('maehongson');




new Vue({
    el: "#listDate",
    data: {
        dates: [],
        currentDate: '',
        rangeSchedule: '',

        addSchedule: [],

        temp: '',
        updateLocation: '',

        offWork: [],
        lampang: [],
        chiangrai: [],
        maehongson: [],

        chiangmai_ils: [],
        chiangmai_commu: [],

        offwork_ils_number: [],
        offwork_commu_number: [],
        balance_ils:'',
        balance_commu:'',

        currentActive_ils:'',
        currentActive_commu:''

    },
    methods: {
        addDate: function () {
            dates_size = this.dates.length
            latestDate = this.dates[dates_size - 1].id
            console.log(latestDate)
            latestLocation = "shiftList/" + latestDate
           
            latestInfo = database.ref(latestLocation)
            latestInfo.on('child_added', snapshot => {
                this.addSchedule.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })
            this.currentDate = date

            var i
            for (i = 0; i <= 19; i++) {
                switch (this.addSchedule[i].status) {
                    case 'chiangmai':
                        continue;
                        break;
                    case 'chiangrai':
                        this.addSchedule[i].status = 'offwork';
                        break;
                    case 'maehongson':
                        this.addSchedule[i].status = 'offwork';
                        break;
                    case 'lampang':
                        this.addSchedule[i].status = 'offwork';
                        break;
                    case 'offwork':
                        this.addSchedule[i].status = 'chiangmai';
                        break;
                }
            }
            shiftList.child(date).set({
                ...this.addSchedule
            })
            while (this.addSchedule.length > 0) {
                this.addSchedule.pop();
            }
            this.getData(date)
        },
        deleteSchedule: function (date, index) {
           
            shiftList.child(date).remove()
            this.dates.splice(index, 1)
        },
        findRangeSchedul: function () {
            date = this.currentDate
            var startDate = new Date(date)
            var fourteenDay = 14 * 24 * 60 * 60 * 1000;
            var endDate = Math.abs(startDate.getTime() + fourteenDay);
            var end_Date = new Date(endDate)
            var S_theyear = startDate.getFullYear();
            var S_themonth = startDate.getMonth() + 1;
            var S_thetoday = startDate.getDate();
            var E_theyear = end_Date.getFullYear();
            var E_themonth = end_Date.getMonth() + 1;
            var E_thetoday = end_Date.getDate();
            this.rangeSchedule = S_thetoday + "/" + S_themonth + "/" + S_theyear + " ถึง " + E_thetoday + "/" + E_themonth + "/" + E_theyear
            console.log(this.rangeSchedule)
        },
        // pull data from each day to dates Array
        getData: function (ids) {

            this.currentDate = ids;
            this.findRangeSchedul()
            newLocation = "shiftList/" + this.currentDate
            this.updateLocation = database.ref(newLocation)

            while (this.offWork.length > 0) {
                this.offWork.pop();
            }
            while (this.lampang.length > 0) {
                this.lampang.pop();
            }
            while (this.chiangrai.length > 0) {
                this.chiangrai.pop();
            }
            while (this.maehongson.length > 0) {
                this.maehongson.pop();
            }
            while (this.chiangmai_ils.length > 0) {
                this.chiangmai_ils.pop();
            }
            while (this.chiangmai_commu.length > 0) {
                this.chiangmai_commu.pop();
            }
            this.offwork_ils_number = 0
            this.offwork_commu_number = 0
            this.balance_commu = 0
            this.balance_ils = 0
            this.currentActive_ils = 0
            this.currentActive_commu = 0


            temp = "shiftList/" + ids
            lampangOnDuty = database.ref(temp).orderByChild('status').equalTo('lampang');
            chiangraiOnDuty = database.ref(temp).orderByChild('status').equalTo('chiangrai');
            maehongsonOnDuty = database.ref(temp).orderByChild('status').equalTo('maehongson');
            chiangmaiOnDuty = database.ref(temp).orderByChild('status').equalTo('chiangmai');
            offWorkEng = database.ref(temp).orderByChild('status').equalTo('offwork');

            lampangOnDuty.on('child_added', snapshot => {
                var engList = snapshot.val();
                for (i = 0; i < this.lampang.length; i++) {
                    if (this.lampang[i].id == snapshot.key) {
                        this.lampang.pop();
                        this.dropActive(engList)
                    }
                }
                this.lampang.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
                var engList = snapshot.val();
                this.insertActive(engList)
                
                
            })
            
            chiangraiOnDuty.on('child_added', snapshot => {
                var engList = snapshot.val();
                for (i = 0; i < this.chiangrai.length; i++) {
                    if (this.chiangrai[i].id == snapshot.key) {
                        this.chiangrai.pop();
                        this.dropActive(engList)
                    }
                }
                this.chiangrai.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
                this.insertActive(engList)
                
            })
            maehongsonOnDuty.on('child_added', snapshot => {
                var engList = snapshot.val();
                for (i = 0; i < this.maehongson.length; i++) {
                    if (this.maehongson[i].id == snapshot.key) {
                        this.maehongson.pop();
                        this.dropActive(engList)
                    }
                }
                this.maehongson.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
                var engList = snapshot.val();
                this.insertActive(engList)
            })
            chiangmaiOnDuty.on('child_added', snapshot => {
                var engList = snapshot.val();
                if (engList.engineer == 'งาน วช.บว') {
                    for (i = 0; i < this.chiangmai_ils.length; i++) {
                        if (this.chiangmai_ils[i].id == snapshot.key) {
                            this.chiangmai_ils[i].pop();
                        }
                    }
                    this.chiangmai_ils.push({
                        ...snapshot.val(),
                        id: snapshot.key
                    })
                }else{
                    for (i = 0; i < this.chiangmai_commu.length; i++) {
                        if (this.chiangmai_commu[i].id == snapshot.key) {
                            this.chiangmai_commu[i].pop();
                        }
                    }
                    this.chiangmai_commu.push({
                        ...snapshot.val(),
                        id: snapshot.key
                    })
                }
                

            })
            offWorkEng.on('child_added', snapshot => {
                //console.log(snapshot.val());
                var engList = snapshot.val();
                if (engList.engineer == 'งาน วช.บว') {
                   this.offwork_ils_number += 1;
                }else{
                    this.offwork_commu_number += 1;
                }
                this.offWork.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })
            this.numberSuggest()
            console.log(this.currentActive_ils +'/' +this.balance_ils)
            console.log(this.currentActive_commu +'/' +this.balance_commu)
        },

        numberSuggest: function(){
            this.balance_ils = 5 - this.offwork_ils_number
            this.balance_commu = 5 - this.offwork_commu_number
        },

        insertActive: function(data){
            if (data.engineer == 'งาน วช.บว') {
                this.currentActive_ils += 1;
            }else{
                this.currentActive_commu += 1;
            }
        },
        dropActive: function(data){
            if (data.engineer == 'งาน วช.บว') {
                this.currentActive_ils -= 1;
            }else{
                this.currentActive_commu -= 1;
            }
        },

        // LAMPANG
        lampangToChiangrai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangrai'
            })
            this.lampang.splice(index, 1)
        },
        lampangToMaehongson: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'maehongson'
            })
            this.lampang.splice(index, 1)
        },
        lampangToChiangmai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangmai'
            })
            this.lampang.splice(index, 1)
            this.dropActive(data)
        },

        // CHIANG RAI
        chiangraiToLampang: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'lampang'
            })
            this.chiangrai.splice(index, 1)
        },
        chiangraiToMaehongson: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'maehongson'
            })
            this.chiangrai.splice(index, 1)
        },
        chiangraiToChiangmai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangmai'
            })
            this.chiangrai.splice(index, 1)
            this.dropActive(data)
        },

        // MAE HONG SON
        maehongsonToLampang: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'lampang'
            })
            this.maehongson.splice(index, 1)
        },
        maehongsonToChiangrai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangrai'
            })
            this.maehongson.splice(index, 1)
        },
        maehongsonToChiangmai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangmai'
            })
            this.maehongson.splice(index, 1)
            this.dropActive(data)
        },
        // CHIANG MAI
        chiangmaiToLampang: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'lampang'
            })
            if (data.engineer == 'งาน วช.บว') {
                this.chiangmai_ils.splice(index, 1)
            }else{
                this.chiangmai_commu.splice(index, 1)
            }
            

        },
        chiangmaiToChiangrai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangrai'
            })
            if (data.engineer == 'งาน วช.บว') {
                this.chiangmai_ils.splice(index, 1)
            }else{
                this.chiangmai_commu.splice(index, 1)
            }
           
        },
        chiangmaiToMaehongson: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'maehongson'
            })
            if (data.engineer == 'งาน วช.บว') {
                this.chiangmai_ils.splice(index, 1)
            }else{
                this.chiangmai_commu.splice(index, 1)
            }
            
        },
    },
    created() {
        shiftList.on('child_added', snapshot => {
            this.dates.push({
                id: snapshot.key
            });
        })
        this.offwork_ils_number = 0;
        this.offwork_commu_number = 0;



    }
})