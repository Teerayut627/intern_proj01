var database = firebase.database();
var shiftList = database.ref('shiftList');


// const lampangOnDuty = database.ref('lampang');
// const chiangraiOnDuty = database.ref('chiangrai');
// const maehongsonOnDuty = database.ref('maehongson');




new Vue({
    el: "#listDate",
    data: {
        dates: [],
        currentDate: '',
        rangeSchedule: '',

        addSchedule: [],

        temp: '',
        updateLocation: '',

        offWork: [],
        lampang: [],
        chiangrai: [],
        maehongson: [],
        chiangmai: []

    },
    methods: {
        addDate: function () {
            dates_size = this.dates.length
            latestDate = this.dates[dates_size - 1].id
            console.log(latestDate)
            latestLocation = "shiftList/" + latestDate
            console.log(latestLocation)
            latestInfo = database.ref(latestLocation)
            latestInfo.on('child_added', snapshot => {
                this.addSchedule.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })
            this.currentDate = date

            var i
            for (i = 0; i <= 19; i++) {
                switch (this.addSchedule[i].status) {
                    case 'chiangmai':
                        continue;
                        break;
                    case 'chiangrai':
                        this.addSchedule[i].status = 'offwork';
                        break;
                    case 'maehongson':
                        this.addSchedule[i].status = 'offwork';
                        break;
                    case 'lampang':
                        this.addSchedule[i].status = 'offwork';
                        break;
                    case 'offwork':
                        this.addSchedule[i].status = 'chiangmai';
                        break;
                }
            }
            shiftList.child(date).set({
                ...this.addSchedule
            })
            while (this.addSchedule.length > 0) {
                this.addSchedule.pop();
            }
            this.getData(date)
        },
        deleteSchedule: function (date, index) {
            console.log('clicked')
            shiftList.child(date).remove()
            this.dates.splice(index, 1)
        },
        findRangeSchedul: function () {
            date = this.currentDate
            var startDate = new Date(date)
            var fourteenDay = 14 * 24 * 60 * 60 * 1000;
            var endDate = Math.abs(startDate.getTime() + fourteenDay);
            var end_Date = new Date(endDate)
            var S_theyear = startDate.getFullYear();
            var S_themonth = startDate.getMonth() + 1;
            var S_thetoday = startDate.getDate();
            var E_theyear = end_Date.getFullYear();
            var E_themonth = end_Date.getMonth() + 1;
            var E_thetoday = end_Date.getDate();
            this.rangeSchedule = S_thetoday + "/" + S_themonth + "/" + S_theyear + " ถึง " + E_thetoday + "/" + E_themonth + "/" + E_theyear
            console.log(this.rangeSchedule)
        },
        // pull data from each day to dates Array
        getData: function (ids) {

            this.currentDate = ids;
            this.findRangeSchedul()
            newLocation = "shiftList/" + this.currentDate
            this.updateLocation = database.ref(newLocation)

            while (this.offWork.length > 0) {
                this.offWork.pop();
            }
            while (this.lampang.length > 0) {
                this.lampang.pop();
            }
            while (this.chiangrai.length > 0) {
                this.chiangrai.pop();
            }
            while (this.maehongson.length > 0) {
                this.maehongson.pop();
            }
            while (this.chiangmai.length > 0) {
                this.chiangmai.pop();
            }



            temp = "shiftList/" + ids
            lampangOnDuty = database.ref(temp).orderByChild('status').equalTo('lampang');
            chiangraiOnDuty = database.ref(temp).orderByChild('status').equalTo('chiangrai');
            maehongsonOnDuty = database.ref(temp).orderByChild('status').equalTo('maehongson');
            chiangmaiOnDuty = database.ref(temp).orderByChild('status').equalTo('chiangmai');
            offWorkEng = database.ref(temp).orderByChild('status').equalTo('offwork');

            lampangOnDuty.on('child_added', snapshot => {
                for (i = 0; i < this.lampang.length; i++) {
                    if (this.lampang[i].id == snapshot.key) {
                        this.lampang.pop();
                    }
                }
                this.lampang.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })

            chiangraiOnDuty.on('child_added', snapshot => {
                for (i = 0; i < this.chiangrai.length; i++) {
                    if (this.chiangrai[i].id == snapshot.key) {
                        this.chiangrai.pop();
                    }
                }
                this.chiangrai.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })
            maehongsonOnDuty.on('child_added', snapshot => {
                for (i = 0; i < this.maehongson.length; i++) {
                    if (this.maehongson[i].id == snapshot.key) {
                        this.maehongson.pop();
                    }
                }
                this.maehongson.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })
            chiangmaiOnDuty.on('child_added', snapshot => {
                for (i = 0; i < this.chiangmai.length; i++) {
                    if (this.chiangmai[i].id == snapshot.key) {
                        this.chiangmai.pop();
                    }
                }
                this.chiangmai.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })
            offWorkEng.on('child_added', snapshot => {
                //console.log(snapshot.val());
                this.offWork.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })
        },
        // LAMPANG
        lampangToChiangrai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangrai'
            })
            this.lampang.splice(index, 1)
        },
        lampangToMaehongson: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'maehongson'
            })
            this.lampang.splice(index, 1)
        },
        lampangToChiangmai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangmai'
            })
            this.lampang.splice(index, 1)
        },

        // CHIANG RAI
        chiangraiToLampang: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'lampang'
            })
            this.chiangrai.splice(index, 1)
        },
        chiangraiToMaehongson: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'maehongson'
            })
            this.chiangrai.splice(index, 1)
        },
        chiangraiToChiangmai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangmai'
            })
            this.chiangrai.splice(index, 1)
        },

        // MAE HONG SON
        maehongsonToLampang: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'lampang'
            })
            this.maehongson.splice(index, 1)
        },
        maehongsonToChiangrai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangrai'
            })
            this.maehongson.splice(index, 1)
        },
        maehongsonToChiangmai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangmai'
            })
            this.maehongson.splice(index, 1)
        },
        // CHIANG MAI
        chiangmaiToLampang: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'lampang'
            })
            this.chiangmai.splice(index, 1)

        },
        chiangmaiToChiangrai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangrai'
            })
            this.chiangmai.splice(index, 1)
        },
        chiangmaiToMaehongson: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'maehongson'
            })
            this.chiangmai.splice(index, 1)
        },
        removeDate: function () {

        }
    },
    created() {
        shiftList.on('child_added', snapshot => {
            this.dates.push({
                id: snapshot.key
            });
        })

    }
})