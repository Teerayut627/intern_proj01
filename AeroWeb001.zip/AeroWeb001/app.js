var database = firebase.database();
var shiftList = database.ref('shiftList');


// const lampangOnDuty = database.ref('lampang');
// const chiangraiOnDuty = database.ref('chiangrai');
// const maehongsonOnDuty = database.ref('maehongson');



new Vue({
    el: "#listDate",
    data: {
        dates: [],
        currentDate: '',
        addSchedule: [],
        temp: '',
        updateLocation: '',
        offWork: [],
        lampang: [],
        chiangrai: [],
        maehongson: [],
        chiangmai: []

    },
    methods: {
        addDate: function () {
            // shiftList.child(date).set({
            //     name: 'yut'
            // })
            dates_size = this.dates.length
            latestDate = this.dates[dates_size - 1].id
            console.log(latestDate)
            latestLocation = "shiftList/" + latestDate
            console.log(latestLocation)
            latestInfo = database.ref(latestLocation)
            latestInfo.on('child_added', snapshot => {
                this.addSchedule.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })
            console.log(this.addSchedule)

            var i
            for (i = 0; i <= 19; i++) {
                switch (this.addSchedule[i].status) {
                    case 'chiangmai':
                        continue;
                        break;
                    case 'chiangrai':
                        this.addSchedule[i].status = 'offwork';
                        break;
                    case 'maehongson':
                        this.addSchedule[i].status = 'offwork';
                        break;
                    case 'lampang':
                        this.addSchedule[i].status = 'offwork';
                        break;
                    case 'offwork':
                        this.addSchedule[i].status = 'chiangmai';
                        break;
                }
            }
            
            shiftList.child(date).set({
                ...this.addSchedule
            })
            while (this.addSchedule.length > 0) {
                this.addSchedule.pop();
            }



        },
        // pull data from each day to dates Array
        getData: function (ids) {

            this.currentDate = ids;
            newLocation = "shiftList/" + this.currentDate
            this.updateLocation = database.ref(newLocation)

            while (this.offWork.length > 0) {
                this.offWork.pop();
            }
            while (this.lampang.length > 0) {
                this.lampang.pop();
            }
            while (this.chiangrai.length > 0) {
                this.chiangrai.pop();
            }
            while (this.maehongson.length > 0) {
                this.maehongson.pop();
            }
            while (this.chiangmai.length > 0) {
                this.chiangmai.pop();
            }

            temp = "shiftList/" + ids
            lampangOnDuty = database.ref(temp).orderByChild('status').equalTo('lampang');
            chiangraiOnDuty = database.ref(temp).orderByChild('status').equalTo('chiangrai');
            maehongsonOnDuty = database.ref(temp).orderByChild('status').equalTo('maehongson');
            chiangmaiOnDuty = database.ref(temp).orderByChild('status').equalTo('chiangmai');
            offWorkEng = database.ref(temp).orderByChild('status').equalTo('offwork');

            lampangOnDuty.on('child_added', snapshot => {
                //console.log(snapshot.val());
                this.lampang.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })

            chiangraiOnDuty.on('child_added', snapshot => {
                //console.log(snapshot.val());
                this.chiangrai.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })
            maehongsonOnDuty.on('child_added', snapshot => {
                //console.log(snapshot.val());
                this.maehongson.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })
            chiangmaiOnDuty.on('child_added', snapshot => {
                //console.log(snapshot.val());
                this.chiangmai.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })
            offWorkEng.on('child_added', snapshot => {
                //console.log(snapshot.val());
                this.offWork.push({
                    ...snapshot.val(),
                    id: snapshot.key
                });
            })
        },
        // LAMPANG
        lampangToChiangrai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangrai'
            })
            this.lampang.splice(index, 1)
        },
        lampangToMaehongson: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'maehongson'
            })
            this.lampang.splice(index, 1)
        },
        lampangToChiangmai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangmai'
            })
            this.lampang.splice(index, 1)
        },

        // CHIANG RAI
        chiangraiToLampang: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'lampang'
            })
            this.chiangrai.splice(index, 1)
        },
        chiangraiToMaehongson: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'maehongson'
            })
            this.chiangrai.splice(index, 1)
        },
        chiangraiToChiangmai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangmai'
            })
            this.chiangrai.splice(index, 1)
        },

        // MAE HONG SON
        maehongsonToLampang: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'lampang'
            })
            this.maehongson.splice(index, 1)
        },
        maehongsonToChiangrai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangrai'
            })
            this.maehongson.splice(index, 1)
        },
        maehongsonToChiangmai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangmai'
            })
            this.maehongson.splice(index, 1)
        },
        // CHIANG MAI
        chiangmaiToLampang: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'lampang'
            })
            this.chiangmai.splice(index, 1)
        },
        chiangmaiToChiangrai: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'chiangrai'
            })
            this.chiangmai.splice(index, 1)
        },
        chiangmaiToMaehongson: function (data, index) {
            this.updateLocation.child(data.id).update({
                'status': 'maehongson'
            })
            this.chiangmai.splice(index, 1)
        },
    },
    created() {
        shiftList.on('child_added', snapshot => {
            this.dates.push({
                id: snapshot.key
            });
        })
    }
})